﻿int[] numbers = new int[3]{34,7,78}; 
int max = numbers[0]; 
for (int index = 0; index < numbers.Length; index++) 
{ 
 if (numbers[index] > max) max = numbers[index]; 
} 
Console.WriteLine(max);