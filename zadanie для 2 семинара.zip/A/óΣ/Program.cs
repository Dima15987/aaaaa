﻿int value = new Random().Next(10, 100);

int max = value / 10;
int min = value % 10;

System.Console.WriteLine($"value: {value} max: {max} min: {min}");